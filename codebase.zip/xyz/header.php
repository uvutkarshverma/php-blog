<link rel="stylesheet" href="../asset//css1//style.css">
<link href="asset/css-min.css" rel="stylesheet" type="text/css">

    
</head>
<body>
    <ul class="ulclass">
   <li><a href='index.php'>POST</a></li>
   <li><a href='category-blog.php'>Category</a></li>
    <li><a href='blog-users.php'>Users</a></li>
    <li><a href="../" target="_blank">Visit Blog </a></li>
    <li><a href='logout.php'><font color="red">Logout</font></a></li>

</ul>