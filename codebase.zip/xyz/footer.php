<div class="footer max-width1 m-auto">
        <h2>Copyright &copy Qnastop.com | All Right Reserved- Developed by Utkarsh</p>
    </div>

    </body> 
</html> 
