<div class="footer max-width1">
   
    <div class="footer-list max-width1 font1">
        <span class="m-auto "><a href="/">Qnastop</a></span>
        <ul class="m-auto">
            <li class="m-auto"><a href="/">HOME</a></li>
            <li class="m-auto"><a href="/privacy-policy">Privacy Policy</a></li>
            
            <li class="m-auto"><a href="/contact">Contact Us</a></li>
            <li class="m-auto"><a href="/link/sitemap.xml">Sitemap</a></li>
        </ul>
    </div>
    
</div>
</body>
<script defer src="/asset/js/script.js"></script>
</html>